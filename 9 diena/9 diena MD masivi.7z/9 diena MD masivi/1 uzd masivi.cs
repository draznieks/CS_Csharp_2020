﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _9_diena_MD_masivi
{
    class _1_uzd_masivi
    {
        public static void uzd1()
        {
            String[] a = new String[6];
            for (int i = 0; i < 6; i++)
            {
                a[i] = "#";
                Console.WriteLine(a[i]);
            }
        }
    }
}
