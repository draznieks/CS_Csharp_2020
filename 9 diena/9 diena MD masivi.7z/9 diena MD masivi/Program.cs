﻿using System;

namespace _9_diena_MD_masivi
{
    class Program
    {
        static void Main(string[] args)
        {

            {
                //1) Uztaisīt String tipa masīvu un ciklā aizpildīt to ar # simbolu (6 simboli)
                //_1_uzd_masivi.uzd1();

                //2) Ar pirmajā uzdevumā izveidotā String masīva palīdzību izvadīt "kasti"
                //_2_uzd_masivi.uzd2();

                //3) Aizpildīt masīvu ar skaitļiem 2,4,6,8,10. To darīt ciklā.
                //_3_uzd_masivi.uzd3();

                //4) Cilvēks izvēlas masīva garumu un aizpilda ar sevis izvēlētiem skaitļiem.
                //_4_uzd_masivi.uzd4();

                //5) Izmantojot 4. uzdevuma masīvu izvadīt visus nepāra skaitļus.
                _5_uzd_masivi.uzd5();
            }

        }

    }
}
